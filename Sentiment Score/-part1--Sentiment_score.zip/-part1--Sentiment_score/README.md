# Sentiment Score
将新闻的动态情感分根据分类数量通过softmax拉伸得到积极的概率和消极的概率，并作为积极情感分和消极情感分.
中文：Bert
日文：XLM
